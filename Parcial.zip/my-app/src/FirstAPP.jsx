
// punto 1
import React, { useState } from 'react';

function TimeConverter() {
    const [seconds, setSeconds] = useState('');

    const handleConversion = () => {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const remainingSeconds = seconds % 60;
        
        console.log(`${hours} horas, ${minutes} minutos, ${remainingSeconds} segundos`);
    }

    return (
        <div>
            <input 
                type="number" 
                value={seconds} 
                onChange={(e) => setSeconds(e.target.value)} 
                placeholder="Ingrese segundos"
                style={{ 
                    padding: '10px', 
                    border: '2px solid #007BFF',  // Borde azul
                    borderRadius: '5px', 
                    marginRight: '10px' 
                }} 
            />
            <button 
                onClick={handleConversion} 
                style={{ 
                    padding: '10px 20px', 
                    backgroundColor: '#D8BFD8',  // Color morado claro
                    color: 'white', 
                    border: 'none', 
                    borderRadius: '5px', 
                    cursor: 'pointer' 
                }}
            >
                Convertir
            </button>
        </div>
    );
}

export default TimeConverter;


/*
//punto 2
import React, { useState } from 'react';
import './PhoneCallPricing.css'; // Asegúrate de proporcionar la ruta correcta al archivo CSS

function PhoneCallPricing() {
  const [duration, setDuration] = useState('');
  const [price, setPrice] = useState(null);

  const computePrice = (e) => {
    e.preventDefault();
    const callDuration = parseFloat(duration);

    if (isNaN(callDuration) || callDuration < 0) {
      console.log('La duración ingresada es inválida.');
      return;
    }

    let finalPrice = 0;

    if (callDuration <= 3) {
      finalPrice = 100;
    } else {
      finalPrice = 100 + (callDuration - 3) * 50;
    }

    console.log('Precio total de la llamada:', finalPrice, 'pesos');
    setPrice(finalPrice);
  };

  return (
    <div className="pricing-container">
      <h2>Tarificador de Llamadas</h2>
      <form onSubmit={computePrice}>
        <div className="input-container">
          <label htmlFor="duration">Duración de la llamada (minutos):</label>
          <input
            type="number"
            id="duration"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            required
          />
        </div>
        <div className="button-container">
          <button type="submit">Calcular Precio</button>
        </div>
      </form>
      {price !== null && <p className="price-display">Precio total: {price} pesos</p>}
    </div>
  );
}

export default PhoneCallPricing;

/*

// Punto 3

import React, { useState } from 'react';

function GreetingComponent() {
  const [name, setName] = useState('');
  const [time, setTime] = useState('');
  const [greetingMessage, setGreetingMessage] = useState('');

  const handleGreeting = () => {
    const hour = parseInt(time.split(':')[0]);

    if (hour >= 0 && hour < 12) {
      setGreetingMessage(`Buenos días, ${name}`);
    } else if (hour >= 12 && hour < 18) {
      setGreetingMessage(`Buenas tardes, ${name}`);
    } else {
      setGreetingMessage(`Buenas noches, ${name}`);
    }
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Saludo según la hora</h2>
      <div>
        <label>
          Nombre:
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input-field"
          />
        </label>
      </div>
      <div>
        <label>
          Hora (formato HH:MM):
          <input
            type="text"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="input-field"
          />
        </label>
      </div>
      <div>
        <button onClick={handleGreeting} className="btn">
          Obtener Saludo
        </button>
      </div>
      <div>
        <p>{greetingMessage}</p>
      </div>
    </div>
  );
}

export default GreetingComponent;

*/