import logo from './logo.svg';
import './App.css';
import FirstAPP from './FirstAPP';

function App() {
  return (
    <div className="App">
     <h1>ENCARA MESSI</h1>
     <h2>GOLL</h2>
     <img src = 'https://media.tenor.com/Wfu7RgbfwsMAAAAM/messi-world-cup.gif'></img>
     <FirstAPP></FirstAPP>
    </div>

  );
}

export default App;